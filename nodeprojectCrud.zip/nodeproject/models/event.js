const mongoose = require('mongoose'),
      Schema = mongoose.Schema;

const eventSchema = new Schema({
    title:{
        type : String,
        required : true
    },
    price:{
        type : Number,
        default : 500
    },
    description:{
        type : String,
        required : true
    },},{
        timestamps :true
    })


//CREATE MODEL
const Event = mongoose.model('Event',eventSchema);

//MODEL EXPORTS
module.exports = Event;