// const { default: mongoose } = require('mongoose');

// TO LOAD ENVIROMENT VARIABLES (dotenv file)
require('dotenv').config();

// ALL DEPENDANCIES

const express = require('express'),
      app = express(),
      expresslayout = require('express-ejs-layouts'),
      mongoose = require('mongoose'),
      port  = process.env.PORT;

//STATIC MIDDLEWARE

app.use(express.static(__dirname + "/public"));


//VIEW ENGINES
app.set('view engine' , 'ejs');
app.use(expresslayout);

// DATABASE CONNTECTION
mongoose.connect(process.env.DB_URI);
// const connectiondb = mongoose.connection;
// try{
//     connectiondb.on('open',()=>{
//         console.log('Connection created successfully');
//     })
// }
// catch(err){
//     console.log(err.message);
// }
(async()=>{
    mongoose.connect(process.env.DB_URI);
    const db = mongoose.connection;
    db.on('error' , console.error.bind(console , "Connection Failed"))
    db.once('open' , ()=> { console.log("Database Connected Successfully")})
})();

//SET MIDDLEWARE ROUTING
app.use(require('./routes/router'))


//RUNNING APPLICATION SERVER

app.listen(port , ()=>{
	console.log(`the server is running on localhost : ${port}`);
})




// require('dotenv').config();

// const express = require('express'),
//       app     = express() ,
//       expressLayout = require('express-ejs-layouts'),
//       mongoose = require('mongoose'),
//       port = process.env.PORT;



// app.use(express.static(__dirname + "/public"));
// app.use('/node_modules' , express.static(__dirname + "/node_modules"));

// app.set('view engine' , 'ejs');
// app.use(expressLayout);

// // Database Connection
// (async()=>{
//     mongoose.connect("mongodb://0.0.0.0:27017/nodedemo");
//     const db = mongoose.connection;
//     db.on('error' , console.error.bind(console , "Connection Failed"))
//     db.once('open' , ()=> { console.log("Database Connected Successfully")})
// })();

// app.use(express.urlencoded({extended : false}))

// app.use(require('./routes/router'));


// app.listen(port , () => {
//     console.log(`Server running on localhost:${port}`);
// });


