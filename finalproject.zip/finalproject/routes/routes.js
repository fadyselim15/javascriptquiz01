const express = require("express");
const router = express.Router();
const User = require('../models/users');
const multer = require('multer');
const users = require("../models/users");
const fs = require("fs");

//image upload
var storage = multer.diskStorage({
    destination :function(req,file,cd){
        cd(null,'./uploads');
    },
    filename :function(req,file,cd){
        cd(null,file.fieldname+"_"+Date.now()+"_"+file.originalname)
    }
});

//middleware to upload data
var uploads =multer({
    storage:storage,
}).single("image");

//upload user data
router.post('/add',uploads,(req,res)=>{
    const user = new User({
        name : req.body.name,
        email : req.body.email,
        phone : req.body.phone,
        image : req.file.filename,
    });
    user.save().then(() => {
    // Handle success
})
  .catch((error) => {
    // Handle error
  });
            res.redirect('/');
        }

)

router.get("/",(req,res)=>{
User.findById().exec()
.then(async(users) =>{
    users = await User.find();
    res.render('index',{
        title : 'Home Page',
        users : users,
    });
}).catch((err)=>{
    res.json({message : err.message});
})
});

//Adding Users
router.get("/add",(req,res)=>{
    res.render("addusers",{title:"Add User"})
});

//Editing Users
router.get("/edit/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const user = await User.findById(id);
  
      if (!user) {
        return res.redirect('/');
      }
  
      res.render("edituser.ejs", {
        title: "Edit User",
        user: user,
      });
    } catch (err) {
      res.redirect('/');
    }
  });

// updating user

router.post('/update/:id', uploads, async (req, res) => {
    try {
      const id = req.params.id;
      const { name, email, phone } = req.body;
      let new_image = '';
  
      if (req.file) {
        new_image = req.file.filename;
        try {
          fs.unlinkSync("./uploads/" + req.body.old_image);
        } catch (err) {
          console.log(err);
        }
      } else {
        new_image = req.body.old_image;
      }
  
      const result = await User.findByIdAndUpdate(id, {
        name: name,
        email: email,
        phone: phone,
        image: new_image,
      });
  
      if (!result) {
        return res.json({ message: 'User not found', type: 'danger' });
      }
  
      req.session.message = {
        type: 'success',
        message: 'User updated successfully',
      };
      res.redirect('/');
    } catch (err) {
      res.json({ message: err.message, type: 'danger' });
    }
  });



// Delete user
// router.get('/delete/:id',(req,res)=>{
//     const id = req.params.id;
//     User.findByIdAndRemove(id,(err,result)=>{
//         if(result.imag != '' ){
//             try{
//                 fs.lutimesSync('./uploads'+result.image);
//             }catch(err){
//                 console.log(err);
//             }
//         }
//         if(err){
//             res.json({message : err.message});
//         } else{
//             req.session.message = {
//                 type: 'info',
//                 message: 'User delete successfully',
//             };
//             res.redirect('/');
//         }
//     } )
// })
router.get('/delete/:id', async (req, res) => {
    try {
      const id = req.params.id;
      const user = await User.findById(id);
  
      if (!user) {
        return res.json({ message: 'User not found' });
      }
  
      if (user.image !== '') {
        try {
          fs.unlinkSync('./uploads/' + user.image);
        } catch (err) {
          console.log(err);
        }
      }
  
      const result = await User.findByIdAndRemove(id);
  
      req.session.message = {
        type: 'info',
        message: 'User deleted successfully',
      };
      res.redirect('/');
    } catch (err) {
      res.json({ message: err.message });
    }
  });

module.exports = router;