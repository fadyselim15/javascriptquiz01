const express = require("express");
const router = express.Router();
const User = require('../models/users');
const multer = require('multer');

//image upload
var storage = multer.diskStorage({
    destination :function(req,file,cd){
        cd(null,'./uploads');
    },
    filename :function(req,file,cd){
        cd(null,file.fieldname+"_"+Date.now()+"_"+file.originalname)
    }
});

//middleware to upload data
var uploads =multer({
    storage:storage,
}).single("image");

//upload user data
router.post('/add',uploads,(req,res)=>{
    const user = new User({
        name : req.body.name,
        email : req.body.email,
        phone : req.body.phone,
        image : req.file.filename,
    });
    user.save().then(() => {
    // Handle success
})
  .catch((error) => {
    // Handle error
  });
            res.redirect('/');
        }

)

router.get("/",(req,res)=>{
    User.find().exec((err,users)).then(()=>{
      res.render("index",{
        title:"home page",
        users:users,
      })
    })
    .catch((error)=>{

    });
   
});
router.get("/add",(req,res)=>{
    res.render("addusers",{title:"Add User"})
});

module.exports = router;